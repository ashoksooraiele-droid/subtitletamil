package com.example.subtitletamil

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class SubtitleItem(
    val index: String,
    val timestamp: String,
    val originalText: String,
    val translatedText: String = ""
)

object SrtParser {
    fun parse(rawContent: String): List<SubtitleItem> {
        val normalized = rawContent.replace("\r\n", "\n").trim()
        if (normalized.isEmpty()) return emptyList()

        val blocks = normalized.split(Regex("\n\s*\n"))
        val items = mutableListOf<SubtitleItem>()

        for ((idx, block) in blocks.withIndex()) {
            val lines = block.lines().map { it.trimEnd() }.filter { it.isNotEmpty() }
            if (lines.isEmpty()) continue

            when {
                lines.size >= 3 && lines[1].contains("-->") -> {
                    items.add(
                        SubtitleItem(
                            index = lines[0],
                            timestamp = lines[1],
                            originalText = lines.drop(2).joinToString("\n")
                        )
                    )
                }
                lines.size >= 2 && lines[0].contains("-->") -> {
                    items.add(
                        SubtitleItem(
                            index = (idx + 1).toString(),
                            timestamp = lines[0],
                            originalText = lines.drop(1).joinToString("\n")
                        )
                    )
                }
                else -> {
                    items.add(
                        SubtitleItem(
                            index = (idx + 1).toString(),
                            timestamp = "",
                            originalText = lines.joinToString("\n")
                        )
                    )
                }
            }
        }
        return items
    }

    fun exportSrt(items: List<SubtitleItem>): String {
        return items.joinToString("\n\n") { item ->
            val text = item.translatedText.ifBlank { item.originalText }
            if (item.timestamp.isNotBlank()) {
                "${item.index}\n${item.timestamp}\n$text"
            } else {
                text
            }
        }
    }
}

class TranslationEngine {
    private var offlineTranslator: Translator? = null

    private fun getOrCreateOfflineTranslator(): Translator {
        return offlineTranslator ?: run {
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.TAMIL)
                .build()
            Translation.getClient(options).also { offlineTranslator = it }
        }
    }

    suspend fun ensureOfflineModelReady(
        onDownloadProgress: ((String) -> Unit)? = null
    ) {
        onDownloadProgress?.invoke("Offline Tamil model check pannudhu...")
        val translator = getOrCreateOfflineTranslator()
        val conditions = DownloadConditions.Builder().build()
        translator.downloadModelIfNeeded(conditions).await()
        onDownloadProgress?.invoke("Offline Tamil model ready!")
    }

    suspend fun translateOfflineBatch(
        texts: List<String>,
        onProgressUpdate: ((String) -> Unit)? = null
    ): List<String> {
        if (texts.isEmpty()) return emptyList()
        ensureOfflineModelReady(onProgressUpdate)
        val translator = getOrCreateOfflineTranslator()
        return texts.map { line ->
            try {
                translator.translate(line).await()
            } catch (_: Exception) {
                line
            }
        }
    }

    suspend fun translateOnlineBatch(texts: List<String>): List<String> = withContext(Dispatchers.IO) {
        if (texts.isEmpty()) return@withContext emptyList()
        val delimiter = "\n|||\n"
        val joined = texts.joinToString(delimiter)

        try {
            val translatedJoined = requestGoogleTranslate(joined)
            val splitResult = translatedJoined.split(Regex("\s*\|\|\|\s*"))
            if (splitResult.size == texts.size) {
                splitResult.map { it.trim() }
            } else {
                texts.map { single ->
                    try {
                        requestGoogleTranslate(single)
                    } catch (_: Exception) {
                        single
                    }
                }
            }
        } catch (_: Exception) {
            texts.map { single ->
                try {
                    requestGoogleTranslate(single)
                } catch (_: Exception) {
                    single
                }
            }
        }
    }

    private fun requestGoogleTranslate(text: String): String {
        val encoded = URLEncoder.encode(text, "UTF-8")
        val urlStr =
            "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ta&dt=t&q=$encoded"
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("User-Agent", "Mozilla/5.0")
        }

        return try {
            val response = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONArray(response)
            val sentences = root.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until sentences.length()) {
                val part = sentences.getJSONArray(i)
                if (!part.isNull(0)) {
                    sb.append(part.getString(0))
                }
            }
            sb.toString().ifBlank { text }
        } finally {
            conn.disconnect()
        }
    }

    fun close() {
        offlineTranslator?.close()
        offlineTranslator = null
    }
}
