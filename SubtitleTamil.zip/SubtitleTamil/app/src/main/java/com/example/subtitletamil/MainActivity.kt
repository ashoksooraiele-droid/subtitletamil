package com.example.subtitletamil

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var pickButton: Button
    private var sourceName = "subtitle"
    private var result: String = ""

    private val pickFile = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { startTranslate(it) } }

    private val saveFile = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/x-subrip")
    ) { uri -> uri?.let { writeOutput(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        pickButton = findViewById(R.id.btnPick)
        pickButton.setOnClickListener { pickFile.launch(arrayOf("*/*")) }
    }

    private fun startTranslate(uri: Uri) {
        sourceName = uri.lastPathSegment?.substringAfterLast('/')
            ?.substringBeforeLast('.') ?: "subtitle"
        pickButton.isEnabled = false
        lifecycleScope.launch {
            try {
                status.text = "File padikkuren..."
                val text = withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)!!
                        .bufferedReader(Charsets.UTF_8).readText()
                }
                result = translateSrt(text)
                status.text = "Mudinjuthu! Save pannunga."
                saveFile.launch("${sourceName}_tamil.srt")
            } catch (e: Exception) {
                status.text = "Error: ${e.message}"
            } finally {
                pickButton.isEnabled = true
            }
        }
    }

    private suspend fun translateSrt(srt: String): String {
        val lines = srt.removePrefix("﻿").replace("\r\n", "\n").lines()
        val isIndex = { s: String -> s.isNotBlank() && s.trim().all { it.isDigit() } }
        val isTime = { s: String -> s.contains("-->") }

        // Language detect: modhal 30 text lines
        val sample = lines.filter {
            it.isNotBlank() && !isIndex(it) && !isTime(it)
        }.take(30).joinToString(" ")

        status.text = "Language kandupidikkuren..."
        val code = LanguageIdentification.getClient()
            .identifyLanguage(sample).await()
        val src = TranslateLanguage.fromLanguageTag(code)
            ?: throw Exception("Language support illa ($code)")

        if (src == TranslateLanguage.TAMIL) throw Exception("Already Tamil")

        val translator = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(src)
                .setTargetLanguage(TranslateLanguage.TAMIL)
                .build()
        )

        try {
            status.text = "Model download aagudhu (modhal dhadava mattum)..."
            translator.downloadModelIfNeeded().await()

            progress.max = lines.size
            val out = StringBuilder()
            lines.forEachIndexed { i, line ->
                val t = if (line.isBlank() || isIndex(line) || isTime(line)) line
                else translator.translate(line).await()
                out.append(t).append("\n")
                progress.progress = i + 1
                status.text = "Translate aagudhu ${(i + 1) * 100 / lines.size}%"
            }
            return out.toString()
        } finally {
            translator.close()
        }
    }

    private fun writeOutput(uri: Uri) {
        contentResolver.openOutputStream(uri)?.use {
            it.write(result.toByteArray(Charsets.UTF_8))
        }
        status.text = "Save aayiduchu!"
    }
}
