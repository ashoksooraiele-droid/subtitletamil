package com.example.subtitletamil

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val engine = TranslationEngine()

    override fun onDestroy() {
        engine.close()
        super.onDestroy()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                SubtitleTranslatorScreen(engine = engine)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubtitleTranslatorScreen(engine: TranslationEngine) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var isOnlineMode by remember { mutableStateOf(true) }
    var autoScrollLive by remember { mutableStateOf(true) }
    var isTranslating by remember { mutableStateOf(false) }
    var isModelPreparing by remember { mutableStateOf(false) }
    var statusText by remember { mutableStateOf("Ready - SRT file load pannunga illa text paste pannunga") }
    var rawInput by remember {
        mutableStateOf(
            """1
00:00:01,000 --> 00:00:03,000
Hello everyone, welcome back!

2
00:00:03,500 --> 00:00:06,000
Today we are testing live Tamil subtitle translation.

3
00:00:06,500 --> 00:00:09,000
You can switch between Online and Offline modes anytime."""
        )
    }

    var subtitleItems by remember { mutableStateOf<List<SubtitleItem>>(emptyList()) }
    var completedCount by remember { mutableIntStateOf(0) }
    var translationJob by remember { mutableStateOf<Job?>(null) }

    val openSrtLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val content = context.contentResolver.openInputStream(uri)
                    ?.bufferedReader(Charsets.UTF_8)
                    ?.use { it.readText() }
                    .orEmpty()
                if (content.isNotBlank()) {
                    translationJob?.cancel()
                    isTranslating = false
                    isModelPreparing = false
                    rawInput = content
                    val parsed = SrtParser.parse(content)
                    subtitleItems = parsed
                    completedCount = 0
                    statusText = "Loaded \${parsed.size} subtitle blocks"
                }
            } catch (e: Exception) {
                statusText = "File read error: \${e.message}"
            }
        }
    }

    val saveSrtLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/x-subrip")
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val outputSrt = SrtParser.exportSrt(subtitleItems)
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(outputSrt.toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(context, "Tamil SRT saved!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                statusText = "Save error: \${e.message}"
            }
        }
    }

    fun triggerOfflineModelDownload() {
        if (isModelPreparing || isTranslating) return
        translationJob = scope.launch {
            isModelPreparing = true
            statusText = "Downloading Offline Tamil Model (ML Kit)..."
            try {
                engine.ensureOfflineModelReady { msg ->
                    statusText = msg
                }
                statusText = "Offline Tamil model ready! Internet illama translate pannalam."
                Toast.makeText(context, "Offline Tamil model ready!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                statusText = "Model download error: \${e.message ?: "Failed"}"
            } finally {
                isModelPreparing = false
            }
        }
    }

    fun startLiveTranslation() {
        translationJob?.cancel()
        val parsed = SrtParser.parse(rawInput)
        if (parsed.isEmpty()) {
            statusText = "Translate panna subtitle text illa"
            return
        }

        subtitleItems = parsed
        completedCount = 0
        val useOnline = isOnlineMode
        val chunkSize = if (useOnline) 10 else 5

        translationJob = scope.launch {
            isTranslating = true
            isModelPreparing = !useOnline
            statusText = if (useOnline) {
                "Online mode: Fast live translating..."
            } else {
                "Offline mode: Checking/Downloading Tamil model..."
            }

            try {
                if (!useOnline) {
                    engine.ensureOfflineModelReady { msg ->
                        statusText = msg
                    }
                    isModelPreparing = false
                }

                val workingList = parsed.toMutableList()
                val indices = workingList.indices.toList()
                val chunks = indices.chunked(chunkSize)

                for (chunkIndices in chunks) {
                    val batchTexts = chunkIndices.map { workingList[it].originalText }
                    val translatedBatch = if (useOnline) {
                        engine.translateOnlineBatch(batchTexts)
                    } else {
                        engine.translateOfflineBatch(batchTexts)
                    }

                    for (i in chunkIndices.indices) {
                        val itemIndex = chunkIndices[i]
                        val translated = translatedBatch.getOrElse(i) { workingList[itemIndex].originalText }
                        workingList[itemIndex] = workingList[itemIndex].copy(translatedText = translated)
                    }

                    completedCount = (completedCount + chunkIndices.size).coerceAtMost(workingList.size)
                    subtitleItems = workingList.toList()
                    statusText = "Live Translating: \$completedCount / \${workingList.size}"

                    if (autoScrollLive && completedCount > 0) {
                        listState.animateScrollToItem((completedCount - 1).coerceAtLeast(0))
                    }
                }

                isTranslating = false
                statusText = "Completed! (\$completedCount / \${parsed.size} blocks)"
            } catch (_: CancellationException) {
                isTranslating = false
                isModelPreparing = false
                statusText = "Stopped (\$completedCount / \${parsed.size})"
            } catch (e: Exception) {
                isTranslating = false
                isModelPreparing = false
                statusText = "Error: \${e.message ?: "Translation failed"}"
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("SubtitleTamil Live") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Mode Switch Card
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isOnlineMode) "Online Mode (Google Fast)" else "Offline Mode (ML Kit)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isOnlineMode) "Batch network translation - Very Fast" else "On-device Tamil model - No internet needed",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Switch(
                            checked = isOnlineMode,
                            onCheckedChange = { enabled ->
                                translationJob?.cancel()
                                isTranslating = false
                                isModelPreparing = false
                                isOnlineMode = enabled
                                statusText = if (enabled) "Switched to Online Mode" else "Switched to Offline Mode"
                            }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Live Auto-Scroll", style = MaterialTheme.typography.bodyMedium)
                        Checkbox(
                            checked = autoScrollLive,
                            onCheckedChange = { autoScrollLive = it }
                        )
                    }

                    if (!isOnlineMode) {
                        OutlinedButton(
                            onClick = { triggerOfflineModelDownload() },
                            enabled = !isModelPreparing && !isTranslating,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                if (isModelPreparing) "Downloading Tamil Model..."
                                else "Download Offline Tamil Model"
                            )
                        }
                    }
                }
            }

            // Input & File Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { openSrtLauncher.launch(arrayOf("*/*")) },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Open SRT")
                }
                OutlinedButton(
                    onClick = {
                        saveSrtLauncher.launch("translated_tamil.srt")
                    },
                    enabled = subtitleItems.any { it.translatedText.isNotBlank() },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Save SRT")
                }
                OutlinedButton(
                    onClick = {
                        val exported = SrtParser.exportSrt(subtitleItems)
                        clipboard.setText(AnnotatedString(exported))
                        Toast.makeText(context, "Copied!", Toast.LENGTH_SHORT).show()
                    },
                    enabled = subtitleItems.any { it.translatedText.isNotBlank() },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Copy")
                }
            }

            OutlinedTextField(
                value = rawInput,
                onValueChange = { rawInput = it },
                label = { Text("SRT / Subtitle Text") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(115.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { startLiveTranslation() },
                    enabled = !isTranslating && !isModelPreparing,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Start Live Translate")
                }
                OutlinedButton(
                    onClick = { translationJob?.cancel() },
                    enabled = isTranslating || isModelPreparing
                ) {
                    Text("Stop")
                }
            }

            Text(
                text = statusText,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium
            )

            if (isModelPreparing) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            } else if (subtitleItems.isNotEmpty()) {
                LinearProgressIndicator(
                    progress = {
                        (completedCount.toFloat() / subtitleItems.size.toFloat()).coerceIn(0f, 1f)
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Live Stream Output View
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(subtitleItems) { _, item ->
                    val isDone = item.translatedText.isNotBlank()
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isDone) {
                                MaterialTheme.colorScheme.secondaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant
                            }
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            if (item.timestamp.isNotBlank()) {
                                Text(
                                    text = "#\${item.index}  \${item.timestamp}",
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                            Text(
                                text = item.originalText,
                                style = MaterialTheme.typography.bodySmall
                            )
                            HorizontalDivider()
                            Text(
                                text = if (isDone) item.translatedText else "Waiting...",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (isDone) FontWeight.SemiBold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }
    }
}
