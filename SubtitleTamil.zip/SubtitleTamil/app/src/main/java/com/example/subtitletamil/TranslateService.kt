package com.example.subtitletamil

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.nio.charset.Charset
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/** Activity-ku progress kaattura shared state. */
object TranslateState {
    val running = MutableStateFlow(false)
    val status = MutableStateFlow("SRT file(s) select pannunga")
    val progress = MutableStateFlow(0)
}

private class Block(val header: List<String>, val text: List<String>)

private class RunResult(
    val ok: Int,
    val total: Int,
    val failed: List<String>,
    val where: String
)

private val assLead = Regex("""^(?:\{\\[^}]*\})+""")
private val assTag = Regex("""\{\\[^}]*\}""")
private val htmlTag = Regex("<[^>]+>")
private val spaces = Regex("\\s+")
private val blockSplit = Regex("\n\\s*\n")

class TranslateService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    @Volatile
    private var lastPct = -1

    private val nm: NotificationManager by lazy {
        getSystemService(NotificationManager::class.java)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            if (job?.isActive == true) job?.cancel() else stopSelf()
            return START_NOT_STICKY
        }

        createChannels()
        startAsForeground("Start aagudhu...")

        if (job?.isActive == true) return START_NOT_STICKY

        val clip = intent?.clipData
        val uris = if (clip == null) emptyList()
        else (0 until clip.itemCount).mapNotNull { clip.getItemAt(it).uri }
        if (uris.isEmpty()) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        job = scope.launch {
            val wl = (getSystemService(POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SubtitleTamil:translate")
            wl.acquire(2 * 60 * 60 * 1000L)
            lastPct = 0
            TranslateState.running.value = true
            TranslateState.progress.value = 0
            try {
                val res = process(uris)
                TranslateState.progress.value = 100
                TranslateState.status.value = summary(res)
                showDone(res)
            } catch (e: CancellationException) {
                TranslateState.status.value = "Stop pannitten."
            } catch (e: Exception) {
                TranslateState.status.value = "Error: ${e.message}"
            } finally {
                TranslateState.running.value = false
                if (wl.isHeld) wl.release()
                ServiceCompat.stopForeground(this@TranslateService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- main flow

    private suspend fun process(uris: List<Uri>): RunResult {
        val translators = HashMap<String, Translator>()
        var ok = 0
        val failed = ArrayList<String>()
        var where = ""
        try {
            uris.forEachIndexed { i, uri ->
                val name = displayName(uri, i)
                try {
                    val out = translateOne(uri, name, i, uris.size, translators)
                    where = withContext(Dispatchers.IO) { saveOutput(name, out) }
                    ok++
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    failed.add("$name: ${e.message}")
                }
            }
        } finally {
            translators.values.forEach { it.close() }
        }
        return RunResult(ok, uris.size, failed, where)
    }

    private suspend fun translateOne(
        uri: Uri,
        name: String,
        idx: Int,
        count: Int,
        translators: MutableMap<String, Translator>
    ): String {
        publishStatus("File ${idx + 1}/$count: $name padikkuren...")
        val raw = withContext(Dispatchers.IO) { readText(uri) }
        val blocks = parseSrt(raw)

        // Language detect: file muzhudhum irundhu 40 lines sample
        val allText = blocks.flatMap { it.text }.map { clean(it) }.filter { s -> s.any { it.isLetter() } }
        if (allText.isEmpty()) throw IOException("Subtitle text illa")
        val step = maxOf(1, allText.size / 40)
        val sample = allText.filterIndexed { i, _ -> i % step == 0 }.take(40).joinToString(" ")

        publishStatus("File ${idx + 1}/$count: language kandupidikkuren...")
        val identifier = LanguageIdentification.getClient()
        val code = try {
            identifier.identifyLanguage(sample).await()
        } finally {
            identifier.close()
        }
        val srcTag = TranslateLanguage.fromLanguageTag(code)
            ?: TranslateLanguage.fromLanguageTag(code.substringBefore('-'))
            ?: throw IOException("Language support illa ($code)")
        if (srcTag == TranslateLanguage.TAMIL) throw IOException("Already Tamil")

        val translator = translators[srcTag] ?: run {
            val t = Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(srcTag)
                    .setTargetLanguage(TranslateLanguage.TAMIL)
                    .build()
            )
            publishStatus("Model download aagudhu (modhal dhadava mattum)...")
            t.downloadModelIfNeeded().await()
            translators[srcTag] = t
            t
        }

        // Speed: subtitle block-ku oru request + 3 requests orey neram + same text cache
        val total = blocks.size
        val done = AtomicInteger(0)
        val cache = ConcurrentHashMap<String, String>()
        val gate = Semaphore(3)
        publish(idx, count, 0, name)

        val outBlocks = coroutineScope {
            blocks.map { b ->
                async {
                    val lines = if (b.text.isEmpty()) b.text
                    else gate.withPermit { translateLines(translator, b.text, cache) }
                    val d = done.incrementAndGet()
                    if (d % 5 == 0 || d == total) publish(idx, count, d * 100 / total, name)
                    b.header + lines
                }
            }.awaitAll()
        }
        return outBlocks.joinToString("\n\n") { it.joinToString("\n") } + "\n"
    }

    // ------------------------------------------------------------ translation

    private suspend fun translateLines(
        tr: Translator,
        lines: List<String>,
        cache: ConcurrentHashMap<String, String>
    ): List<String> {
        val dialogue = lines.size > 1 && lines.drop(1).any {
            val s = it.trimStart()
            s.startsWith("-") || s.startsWith("–")
        }
        if (lines.size == 1 || dialogue) return lines.map { translateLine(tr, it, cache) }

        val joined = lines.joinToString(" ") { clean(it) }.replace(spaces, " ").trim()
        if (!joined.any { it.isLetter() }) return lines
        val prefix = assLead.find(lines[0])?.value.orEmpty()
        val t = translateCached(tr, joined, cache) ?: return lines
        val wrapped = rewrap(prefix + t, lines.size)
        return if (lines.all { it.trim().startsWith("<i>") }) wrapped.map { "<i>$it</i>" } else wrapped
    }

    private suspend fun translateLine(
        tr: Translator,
        line: String,
        cache: ConcurrentHashMap<String, String>
    ): String {
        val cleaned = clean(line).replace(spaces, " ").trim()
        if (!cleaned.any { it.isLetter() }) return line
        val prefix = assLead.find(line)?.value.orEmpty()
        val t = translateCached(tr, cleaned, cache) ?: return line
        val res = prefix + t
        return if (line.trim().startsWith("<i>")) "<i>$res</i>" else res
    }

    private suspend fun translateCached(
        tr: Translator,
        text: String,
        cache: ConcurrentHashMap<String, String>
    ): String? {
        cache[text]?.let { return it }
        return try {
            val r = tr.translate(text).await()
            cache[text] = r
            r
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            null // intha line translate aagala na original-ae irukkum
        }
    }

    private fun clean(s: String): String = s.replace(assTag, "").replace(htmlTag, "")

    private fun rewrap(text: String, n: Int): List<String> {
        if (n <= 1) return listOf(text)
        val words = text.split(' ').filter { it.isNotEmpty() }
        if (words.size < n) return listOf(text)
        val target = text.length / n
        val result = ArrayList<String>()
        val cur = StringBuilder()
        for (w in words) {
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(w)
            if (cur.length >= target && result.size < n - 1) {
                result.add(cur.toString())
                cur.clear()
            }
        }
        if (cur.isNotEmpty()) result.add(cur.toString())
        return result
    }

    // --------------------------------------------------------------- file I/O

    private fun parseSrt(raw: String): List<Block> {
        val norm = raw.removePrefix("﻿").replace("\r\n", "\n").replace('\r', '\n').trim('\n')
        if (norm.isBlank()) return emptyList()
        return norm.split(blockSplit).map { chunk ->
            val lines = chunk.split("\n")
            val ti = lines.indexOfFirst { it.contains("-->") }
            if (ti < 0) Block(lines, emptyList())
            else Block(lines.subList(0, ti + 1), lines.subList(ti + 1, lines.size))
        }
    }

    private fun readText(uri: Uri): String {
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IOException("File open aagala")
        return when {
            bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte() ->
                String(bytes, Charsets.UTF_16LE)
            bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte() ->
                String(bytes, Charsets.UTF_16BE)
            else -> {
                val s = String(bytes, Charsets.UTF_8)
                if (s.contains('�')) String(bytes, Charset.forName("windows-1252")) else s
            }
        }
    }

    private fun displayName(uri: Uri, index: Int): String {
        val n = try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) {
            null
        }
        val base = n?.substringBeforeLast('.')?.takeIf { it.isNotBlank() }
        return base ?: "subtitle_${index + 1}"
    }

    private fun saveOutput(name: String, content: String): String {
        val outName = "${name}_tamil.srt"
        val bytes = content.toByteArray(Charsets.UTF_8)
        return if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, outName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/x-subrip")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SubtitleTamil")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Save panna mudiyala")
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: throw IOException("Save panna mudiyala")
            "Download/SubtitleTamil"
        } else {
            val dir = File(getExternalFilesDir(null), "SubtitleTamil")
            dir.mkdirs()
            File(dir, outName).writeBytes(bytes)
            dir.absolutePath
        }
    }

    // ---------------------------------------------------------- notifications

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH_PROGRESS, "Translate progress", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_DONE, "Translate mudinjadhu", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    private fun startAsForeground(text: String) {
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        ServiceCompat.startForeground(this, NOTIF_PROGRESS, progressNotification(text, 0), type)
    }

    private fun openAppIntent(): PendingIntent =
        PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

    private fun progressNotification(text: String, percent: Int): Notification {
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, TranslateService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Tamil-ku translate aagudhu")
            .setContentText(text)
            .setProgress(100, percent, false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent())
            .addAction(0, "Stop", stop)
            .build()
    }

    private fun publish(fileIdx: Int, count: Int, filePct: Int, name: String) {
        val overall = (fileIdx * 100 + filePct) / count
        val text = "File ${fileIdx + 1}/$count: $name - $filePct%"
        TranslateState.status.value = text
        if (overall != lastPct) {
            lastPct = overall
            TranslateState.progress.value = overall
            nm.notify(NOTIF_PROGRESS, progressNotification(text, overall))
        }
    }

    private fun publishStatus(text: String) {
        TranslateState.status.value = text
        nm.notify(NOTIF_PROGRESS, progressNotification(text, maxOf(0, lastPct)))
    }

    private fun summary(r: RunResult): String {
        val sb = StringBuilder()
        sb.append("${r.ok}/${r.total} file translate aayiduchu.")
        if (r.ok > 0) sb.append(" Save: ${r.where}")
        if (r.failed.isNotEmpty()) {
            sb.append("\nFail: ").append(r.failed.joinToString("; "))
        }
        return sb.toString()
    }

    private fun showDone(r: RunResult) {
        val n = NotificationCompat.Builder(this, CH_DONE)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(if (r.ok == r.total) "Translate mudinjuthu" else "Translate mudinjuthu (sila fail)")
            .setContentText(summary(r).lineSequence().first())
            .setStyle(NotificationCompat.BigTextStyle().bigText(summary(r)))
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()
        nm.notify(NOTIF_DONE, n)
    }

    companion object {
        private const val CH_PROGRESS = "translate_progress"
        private const val CH_DONE = "translate_done"
        private const val NOTIF_PROGRESS = 1
        private const val NOTIF_DONE = 2
        private const val ACTION_STOP = "com.example.subtitletamil.STOP"
    }
}
